"""
REMINISCENT OSINT - IP Geolocation Module

OSINT-safe IP lookup:
- country
- region
- city
- ISP / org
- ASN
- timezone
- approximate lat/lon

DOES NOT return:
- street address
- exact home location
"""

import httpx


API_URL = "https://ipapi.co/{ip}/json/"


async def lookup_ip(ip: str):
    """
    Perform coarse IP geolocation lookup (OSINT-safe)
    """

    if not ip or len(ip.strip()) == 0:
        return {
            "found": False,
            "error": "No IP provided"
        }

    try:
        async with httpx.AsyncClient(timeout=10) as client:
            r = await client.get(API_URL.format(ip=ip.strip()))

        if r.status_code != 200:
            return {
                "found": False,
                "error": f"API request failed ({r.status_code})"
            }

        data = r.json()

        # Basic validation (API sometimes returns error JSON)
        if not isinstance(data, dict) or "error" in data:
            return {
                "found": False,
                "error": "Invalid API response"
            }

        return {
            "found": True,
            "ip": ip,

            # Geographic (coarse)
            "city": data.get("city"),
            "region": data.get("region"),
            "country": data.get("country_name"),
            "country_code": data.get("country_code"),

            # Network info
            "isp": data.get("org"),
            "asn": data.get("asn"),
            "timezone": data.get("timezone"),

            # Approximate coordinates (NOT precise address)
            "latitude": data.get("latitude"),
            "longitude": data.get("longitude"),

            # Extra OSINT metadata
            "postal": data.get("postal"),
            "currency": data.get("currency"),
        }

    except httpx.TimeoutException:
        return {
            "found": False,
            "error": "Request timeout"
        }

    except Exception as e:
        return {
            "found": False,
            "error": str(e)
        }
