# REMINISCENT OSINT

## Overview
A public-data OSINT toolkit with a CLI console, a FastAPI backend, and a browser dashboard. Looks up Instagram profiles, Discord users, Telegram public profiles, and scans usernames across multiple platforms — using only data the platforms expose publicly.

This was originally a clone of the `toutatis` Instagram OSINT tool; the upstream `toutatis` package is still used internally for the Instagram obfuscated email/phone lookup.

## Project Structure
```
reminiscent/
├── main.py              # CLI launcher (menu loop)
├── core/
│   ├── instagram.py     # Instagram lookup
│   ├── discord.py       # Discord user lookup (needs DISCORD_BOT_TOKEN)
│   ├── telegram.py      # Telegram t.me lookup
│   └── username_scan.py # Cross-platform username scanner
├── api/
│   └── app.py           # FastAPI backend
├── web/
│   └── index.html       # Dashboard UI
└── utils/
    ├── http.py          # Shared HTTP helpers
    └── format.py        # ANSI colors + print primitives

toutatis/                # Upstream library (used only for advanced_lookup)
```

## Tech Stack
- Python 3.12
- `requests`, `phonenumbers`, `pycountry` (lookups)
- `fastapi`, `uvicorn` (backend + dashboard server)

## Workflows
- **REMINISCENT CLI** — runs `python3 -m reminiscent.main` (interactive console)
- **REMINISCENT Web** — runs `python3 -m reminiscent.api.app` on port 5000 (dashboard + JSON API)

## API endpoints
- `GET /` — dashboard
- `GET /api/health` — status + whether DISCORD_BOT_TOKEN is configured
- `GET /api/instagram?target=<username|id>&sid=<session>` — Instagram profile
- `GET /api/discord/{user_id}` — Discord user
- `GET /api/telegram/{username}` — Telegram public profile
- `GET /api/scan/{username}` — cross-platform username availability

## Secrets
- `DISCORD_BOT_TOKEN` — bot token from https://discord.com/developers/applications. Required only for Discord lookups.

## Notes
- Instagram requires a session ID (cookie value `sessionid` from instagram.com). Use a throwaway account.
- The Discord/Telegram modules return only public profile fields. Email, phone, last-online status, and connected accounts are not exposed by those platforms' public APIs.
- Use responsibly and only on accounts/data you are authorized to inspect.
