"""REMINISCENT OSINT - Full Backend (Upgraded)

Features:
- Username OSINT scanning
- IP geolocation (coarse OSINT-safe)
- Discord / Instagram / Telegram lookups
- Confidence scoring engine
- Identity correlation engine
- Caching layer for speed
- Frontend dashboard support
"""

import os
import time
from pathlib import Path
from fastapi import FastAPI, Query
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import FileResponse, JSONResponse

from ..core import instagram, discord, telegram, username_scan, profile, ip


# ============================================================
# APP INIT
# ============================================================

app = FastAPI(title="REMINISCENT OSINT API", version="2.0.0")

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_methods=["*"],
    allow_headers=["*"],
)

WEB_DIR = Path(__file__).resolve().parent.parent / "web"


# ============================================================
# CACHE LAYER
# ============================================================

CACHE = {}
CACHE_TTL = 60  # seconds


def get_cached(key):
    data = CACHE.get(key)
    if not data:
        return None

    value, ts = data
    if time.time() - ts > CACHE_TTL:
        return None

    return value


def set_cache(key, value):
    CACHE[key] = (value, time.time())


# ============================================================
# CONFIDENCE SCORING ENGINE
# ============================================================

def score_results(results: dict):
    if not results:
        return 0

    hits = sum(1 for v in results.values() if v)
    return round((hits / len(results)) * 100, 2)


# ============================================================
# IDENTITY CORRELATION ENGINE
# ============================================================

def correlate_identity(results: dict):
    signals = []

    if results.get("GitHub"):
        signals.append("developer footprint")

    if results.get("Reddit"):
        signals.append("forum presence")

    if results.get("Telegram"):
        signals.append("messaging activity")

    if results.get("Instagram"):
        signals.append("social media footprint")

    if results.get("Steam"):
        signals.append("gaming profile")

    return {
        "signals": signals,
        "strength": len(signals)
    }


# ============================================================
# DASHBOARD
# ============================================================

@app.get("/")
def root():
    index = WEB_DIR / "index.html"
    if index.exists():
        return FileResponse(index)
    return {"status": "running"}


# ============================================================
# HEALTH CHECK
# ============================================================

@app.get("/api/health")
def health():
    return {
        "status": "ok",
        "discord_token_configured": bool(os.environ.get("DISCORD_BOT_TOKEN"))
    }


# ============================================================
# IP LOOKUP (OSINT SAFE)
# ============================================================

@app.get("/api/ip")
async def api_ip(ip_address: str = Query(..., alias="ip")):
    try:
        result = await ip.lookup_ip(ip_address)
        return result
    except Exception as e:
        return JSONResponse(
            status_code=500,
            content={"found": False, "error": str(e)}
        )


# ============================================================
# USERNAME SCAN (CACHED)
# ============================================================

@app.get("/api/scan/{username}")
async def api_scan(username: str):

    cache_key = f"scan:{username}"
    cached = get_cached(cache_key)

    if cached:
        return {
            "username": username,
            "cached": True,
            **cached
        }

    results = await username_scan.check(username)

    response = {
        "results": results,
        "confidence": score_results(results),
        "correlation": correlate_identity(results)
    }

    set_cache(cache_key, response)

    return {
        "username": username,
        "cached": False,
        **response
    }


# ============================================================
# PROFILE VIEWER
# ============================================================

@app.get("/api/profile/{platform}/{username}")
async def api_profile(platform: str, username: str):
    data = await profile.fetch_profile(platform, username)

    if "error" in data:
        return JSONResponse(status_code=404, content=data)

    return data


# ============================================================
# PLATFORM ENDPOINTS
# ============================================================

@app.get("/api/instagram")
def api_instagram(target: str = Query(...), sid: str = Query(...)):
    result = instagram.lookup(target, sid)
    if "error" in result:
        return JSONResponse(status_code=400, content=result)
    return result


@app.get("/api/discord/{user_id}")
def api_discord(user_id: str):
    result = discord.lookup(user_id)
    if "error" in result:
        return JSONResponse(status_code=400, content=result)
    return result


@app.get("/api/telegram/{username}")
def api_telegram(username: str):
    result = telegram.lookup(username)
    if "error" in result:
        return JSONResponse(status_code=400, content=result)
    return result


# ============================================================
# SERVER START (REPLIT SAFE)
# ============================================================

def serve():
    import uvicorn
    port = int(os.environ.get("PORT", 5000))
    uvicorn.run(app, host="0.0.0.0", port=port)


if __name__ == "__main__":
    serve()
