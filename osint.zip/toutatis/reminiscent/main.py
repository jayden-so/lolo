"""REMINISCENT OSINT - CLI launcher."""
from .utils.format import C, banner, menu, err
from .core import instagram, discord, telegram, username_scan


def main():
    banner()
    while True:
        menu()
        try:
            choice = input(C.GREY + "> " + C.RESET + "Choice " + C.DIM + "(int)" + C.RESET + " ").strip()
        except (EOFError, KeyboardInterrupt):
            print()
            return
        if choice == "1":
            instagram.run()
        elif choice == "2":
            discord.run()
        elif choice == "3":
            telegram.run()
        elif choice == "4":
            username_scan.run()
        elif choice in ("5", "q", "quit", "exit"):
            print(C.PINK + "Bye!" + C.RESET)
            return
        else:
            err("Pick 1, 2, 3, 4, or 5.")
        print()


if __name__ == "__main__":
    try:
        main()
    except KeyboardInterrupt:
        print()
