"""
Cross-platform username availability scanner (10X OSINT upgrade)

Provides:
- scan(username)           sync CLI scanner
- check(username)          async API scanner
- OSINT enrichment across major platforms
"""

import asyncio
from concurrent.futures import ThreadPoolExecutor, as_completed

import httpx

from ..utils.format import C, ok, info, err, section
from ..utils.http import GENERIC_UA, IG_WEB_HEADERS, get


# ============================================================
#                       SYNC HELPERS (CLI)
# ============================================================

def _status(url, expected=200, **kwargs):
    r, error = get(url, headers=GENERIC_UA, timeout=10, **kwargs)
    if error or r is None:
        return None
    return r.status_code == expected


def check_github(u):    return _status(f"https://github.com/{u}")
def check_gitlab(u):    return _status(f"https://gitlab.com/{u}")
def check_pinterest(u): return _status(f"https://www.pinterest.com/{u}/")
def check_keybase(u):   return _status(f"https://keybase.io/{u}")
def check_dev_to(u):    return _status(f"https://dev.to/{u}")


def check_telegram(u):
    r, error = get(f"https://t.me/{u}", headers=GENERIC_UA, timeout=10)
    if error or r is None:
        return None
    return ("tgme_page_extra" in r.text) or ("tgme_page_title" in r.text)


def check_reddit(u):
    r, error = get(f"https://www.reddit.com/user/{u}/about.json",
                   headers=GENERIC_UA, timeout=10)
    if error or r is None:
        return None
    if r.status_code != 200:
        return False
    try:
        data = r.json()
    except Exception:
        return None
    return "data" in data and "name" in data["data"]


def check_steam(u):
    r, error = get(f"https://steamcommunity.com/id/{u}/",
                   headers=GENERIC_UA, timeout=10)
    if error or r is None:
        return None
    return r.status_code == 200 and "not found" not in r.text.lower()


def check_roblox(u):
    r, error = get(f"https://www.roblox.com/user.aspx?username={u}",
                   headers=GENERIC_UA, timeout=10, allow_redirects=False)
    if error or r is None:
        return None
    return r.status_code in (301, 302)


PLATFORMS = {
    "GitHub":    (check_github,    "https://github.com/{u}"),
    "GitLab":    (check_gitlab,    "https://gitlab.com/{u}"),
    "Pinterest": (check_pinterest, "https://pinterest.com/{u}"),
    "Keybase":   (check_keybase,   "https://keybase.io/{u}"),
    "Dev.to":    (check_dev_to,    "https://dev.to/{u}"),
    "Telegram":  (check_telegram,  "https://t.me/{u}"),
    "Reddit":    (check_reddit,    "https://reddit.com/user/{u}"),
    "Steam":     (check_steam,     "https://steamcommunity.com/id/{u}"),
    "Roblox":    (check_roblox,    "https://www.roblox.com/user.aspx?username={u}"),
}


def scan(username):
    results = []
    with ThreadPoolExecutor(max_workers=10) as ex:
        futures = {
            ex.submit(checker, username): (name, url_t.format(u=username))
            for name, (checker, url_t) in PLATFORMS.items()
        }

        for fut in as_completed(futures):
            name, url = futures[fut]
            try:
                found = fut.result()
            except Exception:
                found = None

            results.append({
                "platform": name,
                "found": found,
                "url": url
            })

    return sorted(results, key=lambda r: r["platform"])


def print_results(username, results):
    section(f"Username scan: {username}")
    for r in results:
        if r["found"] is True:
            ok(C.GREEN + "FOUND    " + C.RESET + r["platform"], r["url"])
        elif r["found"] is False:
            ok(C.GREY + "free     " + C.RESET + r["platform"], r["url"])
        else:
            ok(C.YELLOW + "error    " + C.RESET + r["platform"], r["url"])


def run():
    section("Username scan")
    while True:
        try:
            u = input(C.GREY + "  > " + C.RESET + "Username (blank = back): ").strip()
        except (EOFError, KeyboardInterrupt):
            return
        if not u:
            return

        info(f"Scanning {len(PLATFORMS)} platforms...")
        results = scan(u)
        print_results(u, results)
        print()


# ============================================================
#                ASYNC DETECTORS (API MODE)
# ============================================================

async def _afetch(client, url, **kwargs):
    try:
        return await client.get(url, headers=GENERIC_UA, **kwargs)
    except Exception:
        return None


async def _simple_exists(client, url):
    r = await _afetch(client, url)
    return bool(r) and r.status_code == 200


# ---------- PLATFORM CHECKS ----------

async def _check_github(c, u): return await _simple_exists(c, f"https://github.com/{u}")
async def _check_gitlab(c, u): return await _simple_exists(c, f"https://gitlab.com/{u}")
async def _check_pinterest(c, u): return await _simple_exists(c, f"https://pinterest.com/{u}/")
async def _check_keybase(c, u): return await _simple_exists(c, f"https://keybase.io/{u}")
async def _check_dev_to(c, u): return await _simple_exists(c, f"https://dev.to/{u}")


async def _check_telegram(c, u):
    r = await _afetch(c, f"https://t.me/{u}")
    return bool(r) and ("tgme_page_extra" in r.text or "tgme_page_title" in r.text)


async def _check_reddit(c, u):
    r = await _afetch(c, f"https://www.reddit.com/user/{u}/about.json")
    if not r or r.status_code != 200:
        return False
    try:
        return "data" in r.json()
    except Exception:
        return False


async def _check_steam(c, u):
    r = await _afetch(c, f"https://steamcommunity.com/id/{u}/")
    return bool(r) and r.status_code == 200 and "not found" not in r.text.lower()


async def _check_roblox(c, u):
    r = await _afetch(c, f"https://www.roblox.com/user.aspx?username={u}", follow_redirects=False)
    return bool(r) and r.status_code in (301, 302)


# ---------- NEW OSINT PLATFORMS ----------

async def _check_x(c, u):
    r = await _afetch(c, f"https://x.com/{u}")
    return bool(r) and r.status_code == 200 and "doesn’t exist" not in r.text.lower()


async def _check_tiktok(c, u):
    r = await _afetch(c, f"https://www.tiktok.com/@{u}")
    return bool(r) and r.status_code == 200 and "couldn't find" not in r.text.lower()


async def _check_twitch(c, u):
    r = await _afetch(c, f"https://m.twitch.tv/{u}")
    return bool(r) and r.status_code == 200


async def _check_youtube(c, u):
    r = await _afetch(c, f"https://www.youtube.com/@{u}")
    return bool(r) and r.status_code == 200


async def _check_npm(c, u):
    return await _simple_exists(c, f"https://www.npmjs.com/~{u}")


async def _check_pypi(c, u):
    r = await _afetch(c, f"https://pypi.org/user/{u}/")
    return bool(r) and r.status_code == 200


async def _check_leetcode(c, u):
    r = await _afetch(c, f"https://leetcode.com/{u}/")
    return bool(r) and r.status_code == 200


async def _check_hackerrank(c, u):
    return await _simple_exists(c, f"https://www.hackerrank.com/{u}")


# ============================================================
#                    PLATFORM REGISTRY
# ============================================================

ASYNC_PLATFORMS = {
    "Instagram": (_check_simple := _simple_exists, "https://instagram.com/{u}"),
    "GitHub":    (_check_github, "https://github.com/{u}"),
    "GitLab":    (_check_gitlab, "https://gitlab.com/{u}"),
    "Pinterest": (_check_pinterest, "https://pinterest.com/{u}"),
    "Keybase":   (_check_keybase, "https://keybase.io/{u}"),
    "Dev.to":    (_check_dev_to, "https://dev.to/{u}"),
    "Telegram":  (_check_telegram, "https://t.me/{u}"),
    "Reddit":    (_check_reddit, "https://reddit.com/user/{u}"),
    "Steam":     (_check_steam, "https://steamcommunity.com/id/{u}"),
    "Roblox":    (_check_roblox, "https://www.roblox.com/user.aspx?username={u}"),

    # NEW OSINT LAYERS
    "X (Twitter)": (_check_x, "https://x.com/{u}"),
    "TikTok": (_check_tiktok, "https://tiktok.com/@{u}"),
    "Twitch": (_check_twitch, "https://twitch.tv/{u}"),
    "YouTube": (_check_youtube, "https://youtube.com/@{u}"),
    "npm": (_check_npm, "https://npmjs.com/~{u}"),
    "PyPI": (_check_pypi, "https://pypi.org/user/{u}/"),
    "LeetCode": (_check_leetcode, "https://leetcode.com/{u}/"),
    "HackerRank": (_check_hackerrank, "https://hackerrank.com/{u}"),
}


# ============================================================
#                      MAIN ASYNC SCAN
# ============================================================

async def check(username):
    found = {}

    async with httpx.AsyncClient(timeout=15, follow_redirects=True) as client:

        async def run(name, fn, url_t):
            try:
                ok_ = await fn(client, username)
            except Exception:
                ok_ = False
            return name, ok_, url_t.format(u=username)

        tasks = [
            run(name, fn, url_t)
            for name, (fn, url_t) in ASYNC_PLATFORMS.items()
        ]

        results = await asyncio.gather(*tasks)

    for name, ok_, url in results:
        if ok_:
            found[name] = url

    return found
