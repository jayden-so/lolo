"""Enhanced Telegram public-username lookup via t.me scraping."""

import re
import html

from ..utils.format import C, ok, info, err, section
from ..utils.http import TG_HEADERS, get


def _meta(html_text, prop):
    patterns = [
        rf'<meta\s+property="og:{prop}"\s+content="([^"]+)"',
        rf'<meta\s+name="twitter:{prop}"\s+content="([^"]+)"'
    ]
    for p in patterns:
        m = re.search(p, html_text, re.IGNORECASE)
        if m:
            return html.unescape(m.group(1))
    return None


def _extract(html_text, pattern):
    m = re.search(pattern, html_text, re.IGNORECASE | re.DOTALL)
    return html.unescape(m.group(1).strip()) if m else None


def fetch(username):
    username = username.lstrip("@")

    if not re.fullmatch(r"[A-Za-z0-9_]{3,}", username):
        return None, "Invalid username format"

    r, error = get(f"https://t.me/{username}", headers=TG_HEADERS)
    if error:
        return None, error

    if r.status_code != 200:
        return None, f"HTTP {r.status_code}"

    html_text = r.text

    # --- META ---
    title = _meta(html_text, "title")
    description = _meta(html_text, "description")
    image = _meta(html_text, "image")

    # --- EXTRA INFO ---
    extra = _extract(html_text, r'<div class="tgme_page_extra">([^<]+)</div>')
    about = _extract(html_text, r'<div class="tgme_page_description">(.+?)</div>')

    # --- STATUS FLAGS ---
    verified = "tgme_icon_verified" in html_text
    scam = "tgme_icon_scam" in html_text
    fake = "tgme_icon_fake" in html_text

    # --- TYPE DETECTION ---
    kind = "user"
    members = None

    if extra:
        if "subscribers" in extra.lower():
            kind = "channel"
        elif "members" in extra.lower():
            kind = "group"

        # Extract number
        num = re.search(r"([\d,\.]+)", extra)
        if num:
            members = num.group(1)

    # --- LAST SEEN / STATUS ---
    status = _extract(html_text, r'<div class="tgme_page_status">([^<]+)</div>')

    # --- FALLBACK TITLE ---
    if not title:
        title = _extract(html_text, r'<title>(.*?)</title>')

    if not title and not extra:
        return None, "User not found or private"

    return {
        "username": username,
        "title": title,
        "description": description,
        "about": about,
        "image": image,
        "extra": extra,
        "members": members,
        "kind": kind,
        "verified": verified,
        "scam": scam,
        "fake": fake,
        "status": status,
        "url": f"https://t.me/{username}",
    }, None


def lookup(username):
    data, error = fetch(username)
    if error:
        return {"error": error}
    return data


def print_profile(p):
    section("Telegram Profile")

    ok("Username", "@" + p["username"])
    ok("Type", p["kind"])
    ok("Name", p.get("title") or "Unknown")

    if p.get("description"):
        ok("Description", p["description"].replace("\n", " "))

    if p.get("about"):
        ok("About", p["about"].replace("\n", " "))

    if p.get("members"):
        ok("Members/Subscribers", p["members"])

    if p.get("status"):
        ok("Status", p["status"])

    ok("Verified", "Yes" if p.get("verified") else "No")

    if p.get("scam"):
        err("⚠ Marked as SCAM")
    if p.get("fake"):
        err("⚠ Marked as FAKE")

    if p.get("image"):
        ok("Profile Picture", p["image"])

    ok("URL", p["url"])


def run():
    section("Telegram Lookup")

    while True:
        try:
            uname = input(C.GREY + "  > " + C.RESET + "Telegram @username (blank = exit): ").strip()
        except (EOFError, KeyboardInterrupt):
            return

        if not uname:
            return

        result = lookup(uname)

        if "error" in result:
            err(result["error"])
            continue

        print_profile(result)
        print()
