"""Discord public-user lookup via bot API (fixed + improved)."""

import os
from datetime import datetime, timezone

from ..utils.format import C, ok, info, err, section
from ..utils.http import get_json


DISCORD_API = "https://discord.com/api/v10"
DISCORD_EPOCH = 1420070400000  # ms


PUBLIC_FLAGS = {
    1 << 0: "Discord Employee",
    1 << 1: "Partnered Server Owner",
    1 << 2: "HypeSquad Events",
    1 << 3: "Bug Hunter Level 1",
    1 << 6: "HypeSquad Bravery",
    1 << 7: "HypeSquad Brilliance",
    1 << 8: "HypeSquad Balance",
    1 << 9: "Early Supporter",
    1 << 14: "Bug Hunter Level 2",
    1 << 16: "Verified Bot",
    1 << 17: "Early Verified Bot Developer",
    1 << 18: "Certified Moderator",
    1 << 22: "Active Developer",
}


def snowflake_to_date(snowflake):
    try:
        ts = (int(snowflake) >> 22) + DISCORD_EPOCH
        return datetime.fromtimestamp(ts / 1000, tz=timezone.utc).strftime("%Y-%m-%d %H:%M:%S UTC")
    except Exception:
        return "Unknown"


def decode_flags(flags):
    return [name for bit, name in PUBLIC_FLAGS.items() if flags & bit] if flags else []


def avatar_url(user):
    if user.get("avatar"):
        ext = "gif" if user["avatar"].startswith("a_") else "png"
        return f"https://cdn.discordapp.com/avatars/{user['id']}/{user['avatar']}.{ext}?size=1024"

    # default avatar
    idx = int(user["id"]) % 5
    return f"https://cdn.discordapp.com/embed/avatars/{idx}.png"


def banner_url(user):
    if not user.get("banner"):
        return None
    ext = "gif" if user["banner"].startswith("a_") else "png"
    return f"https://cdn.discordapp.com/banners/{user['id']}/{user['banner']}.{ext}?size=1024"


def fetch(user_id, token=None):
    token = token or os.environ.get("DISCORD_BOT_TOKEN")

    if not token:
        return None, "Missing DISCORD_BOT_TOKEN"

    if not str(user_id).isdigit():
        return None, "User ID must be numeric"

    url = f"{DISCORD_API}/users/{user_id}"

    data, error = get_json(
        url,
        headers={"Authorization": f"Bot {token}"}
    )

    if error:
        if "403" in str(error):
            return None, "Forbidden (bot must share a server with this user)"
        if "401" in str(error):
            return None, "Invalid bot token"
        return None, f"API error: {error}"

    return data, None


def lookup(user_id, token=None):
    user, error = fetch(user_id, token)

    if error:
        return {"error": error}

    username = user.get("username", "Unknown")
    global_name = user.get("global_name")

    return {
        "id": user.get("id"),
        "username": username,
        "display_name": global_name,
        "created_at": snowflake_to_date(user.get("id", "0")),
        "bot": user.get("bot", False),
        "system": user.get("system", False),
        "accent_color": (
            f"#{user['accent_color']:06X}"
            if user.get("accent_color") is not None else None
        ),
        "badges": decode_flags(user.get("public_flags", 0)),
        "avatar_url": avatar_url(user),
        "banner_url": banner_url(user),
    }


def print_profile(p):
    section("Discord Profile")

    ok("Username", p.get("username"))
    if p.get("display_name"):
        ok("Display Name", p["display_name"])

    ok("User ID", p.get("id"))
    ok("Created", p.get("created_at"))
    ok("Bot", "Yes" if p.get("bot") else "No")
    ok("System", "Yes" if p.get("system") else "No")

    if p.get("accent_color"):
        ok("Accent Color", p["accent_color"])

    badges = p.get("badges") or []
    ok("Badges", ", ".join(badges) if badges else "None")

    if p.get("avatar_url"):
        ok("Avatar", p["avatar_url"])

    if p.get("banner_url"):
        ok("Banner", p["banner_url"])


def run():
    section("Discord Lookup")

    if not os.environ.get("DISCORD_BOT_TOKEN"):
        err("DISCORD_BOT_TOKEN not set.")
        info("Get one from https://discord.com/developers/applications")
        return

    while True:
        try:
            uid = input(C.GREY + "  > " + C.RESET + "User ID (blank = exit): ").strip()
        except (EOFError, KeyboardInterrupt):
            return

        if not uid:
            return

        result = lookup(uid)

        if "error" in result:
            err(result["error"])
            continue

        print_profile(result)
        print()
