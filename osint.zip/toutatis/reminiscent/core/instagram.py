"""Instagram public-profile lookup (OSINT enhanced)."""

from getpass import getpass
import phonenumbers
from phonenumbers.phonenumberutil import region_code_for_country_code
import pycountry

from toutatis.core import advanced_lookup
from ..utils.format import C, ok, info, err, section, vstr
from ..utils.http import IG_WEB_HEADERS, IG_MOBILE_HEADERS, get_json, nested


# -------------------------
# CORE FETCHERS
# -------------------------

def fetch_username(username, sid):
    url = f"https://i.instagram.com/api/v1/users/web_profile_info/?username={username}"
    body, error = get_json(url, headers=IG_WEB_HEADERS, cookies={"sessionid": sid})
    if error:
        return None, error

    user = nested(body, "data", "user")
    if not user:
        return None, "User not found"

    return user, None


def fetch_id(uid, sid):
    url = f"https://i.instagram.com/api/v1/users/{uid}/info/"
    body, error = get_json(url, headers=IG_MOBILE_HEADERS, cookies={"sessionid": sid})
    if error:
        return None, error

    user = body.get("user") if isinstance(body, dict) else None
    if not user:
        return None, "User not found"

    return user, None


# -------------------------
# OSINT HELPERS
# -------------------------

def extract_edges_list(edge):
    """
    Extract usernames + ids from Instagram edge structure.
    Used for followers/following OSINT graph expansion.
    """
    try:
        nodes = edge.get("edges", [])
        return [
            {
                "username": n["node"].get("username"),
                "id": n["node"].get("id"),
                "full_name": n["node"].get("full_name"),
                "is_private": n["node"].get("is_private"),
                "is_verified": n["node"].get("is_verified"),
            }
            for n in nodes
            if isinstance(n, dict)
        ]
    except Exception:
        return []


def extract_recent_posts(user):
    """
    Pull last posts from timeline edge (OSINT feed snapshot).
    """
    posts = []
    try:
        media = nested(user, "edge_owner_to_timeline_media", "edges") or []
        for p in media[:6]:
            node = p.get("node", {})
            posts.append({
                "id": node.get("id"),
                "shortcode": node.get("shortcode"),
                "likes": nested(node, "edge_liked_by", "count"),
                "comments": nested(node, "edge_media_to_comment", "count"),
                "caption": (
                    (node.get("edge_media_to_caption", {})
                     .get("edges", [{}])[0]
                     .get("node", {})
                     .get("text"))
                    if node.get("edge_media_to_caption") else None
                )
            })
    except Exception:
        pass
    return posts


# -------------------------
# NORMALIZATION
# -------------------------

def normalize(u):
    return {
        "username": u.get("username"),
        "userID": u.get("id") or u.get("pk"),
        "full_name": u.get("full_name"),
        "is_verified": u.get("is_verified"),
        "is_business": u.get("is_business_account") or u.get("is_business"),
        "is_private": u.get("is_private"),

        "follower_count": nested(u, "edge_followed_by", "count"),
        "following_count": nested(u, "edge_follow", "count"),
        "media_count": nested(u, "edge_owner_to_timeline_media", "count"),

        "usertags_count": u.get("usertags_count"),
        "external_url": u.get("external_url"),
        "biography": u.get("biography") or "",

        "total_igtv_videos": nested(u, "edge_felix_video_timeline", "count"),

        "public_email": u.get("public_email") or u.get("business_email"),
        "public_phone_number": u.get("public_phone_number") or u.get("business_phone_number"),
        "public_phone_country_code": u.get("public_phone_country_code"),

        "profile_pic_url": (
            nested(u, "hd_profile_pic_url_info", "url")
            or u.get("profile_pic_url_hd")
            or u.get("profile_pic_url")
        ),

        # -------------------------
        # OSINT ENHANCEMENTS
        # -------------------------
        "followers_list": extract_edges_list(nested(u, "edge_followed_by")),
        "following_list": extract_edges_list(nested(u, "edge_follow")),
        "recent_posts": extract_recent_posts(u),
    }


def enrich_obfuscated(infos):
    if not infos.get("username"):
        return infos

    try:
        other = advanced_lookup(infos["username"])
    except Exception:
        return infos

    user = (other or {}).get("user") or {}

    if user.get("obfuscated_email"):
        infos["obfuscated_email"] = user["obfuscated_email"]
    if user.get("obfuscated_phone"):
        infos["obfuscated_phone"] = str(user["obfuscated_phone"])

    return infos


# -------------------------
# OUTPUT
# -------------------------

def print_profile(infos):
    section("Instagram OSINT Profile")

    ok("Username", vstr(infos["username"]))
    ok("Name / ID", f"{infos['full_name']} | {infos['userID']}")

    ok("Verified / Business", f"{infos['is_verified']} | {infos['is_business']}")
    ok("Private", vstr(infos["is_private"]))

    ok("Followers / Following",
       f"{infos['follower_count']} / {infos['following_count']}")

    ok("Posts", vstr(infos["media_count"]))
    ok("Tagged posts", vstr(infos["usertags_count"]))
    ok("IGTV", vstr(infos["total_igtv_videos"]))

    if infos.get("external_url"):
        ok("External URL", infos["external_url"])

    bio = infos["biography"]
    if bio:
        ok("Biography", ("\n" + " " * 20).join(bio.split("\n")))

    # ---------------- EMAIL / PHONE ----------------
    if infos.get("public_email"):
        ok("Public Email", infos["public_email"])

    if infos.get("public_phone_number"):
        cc = infos.get("public_phone_country_code") or ""
        ph = f"+{cc} {infos['public_phone_number']}"
        try:
            pn = phonenumbers.parse(ph)
            region = region_code_for_country_code(pn.country_code)
            country = pycountry.countries.get(alpha_2=region)
            if country:
                ph += f" ({country.name})"
        except Exception:
            pass
        ok("Public Phone", ph)

    # ---------------- OBFUSCATED ----------------
    if infos.get("obfuscated_email"):
        ok("Obfuscated Email", infos["obfuscated_email"])
    if infos.get("obfuscated_phone"):
        ok("Obfuscated Phone", infos["obfuscated_phone"])

    print(C.DIM + "  " + "-" * 40 + C.RESET)

    if infos.get("profile_pic_url"):
        ok("Profile Picture", infos["profile_pic_url"])

    # ---------------- OSINT GRAPH ----------------
    print(C.DIM + "\n  [OSINT GRAPH DATA]" + C.RESET)

    followers = infos.get("followers_list", [])[:10]
    following = infos.get("following_list", [])[:10]

    if followers:
        ok("Sample Followers", ", ".join([f.get("username") for f in followers if f.get("username")]))

    if following:
        ok("Sample Following", ", ".join([f.get("username") for f in following if f.get("username")]))

    # ---------------- RECENT POSTS ----------------
    posts = infos.get("recent_posts", [])
    if posts:
        print(C.DIM + "\n  [RECENT POSTS]" + C.RESET)
        for p in posts:
            ok("Post", f"{p['shortcode']} | likes:{p['likes']} comments:{p['comments']}")


# -------------------------
# LOOKUP ENTRYPOINT
# -------------------------

def lookup(target, sid):
    if not target:
        return {"error": "No target"}

    user, error = (
        fetch_id(target, sid)
        if str(target).isdigit()
        else fetch_username(target, sid)
    )

    if error:
        return {"error": error}

    return enrich_obfuscated(normalize(user))


# -------------------------
# CLI
# -------------------------

def run():
    section("Instagram OSINT Tool")

    info("Session ID required (browser cookie from instagram.com)")
    info("Use a throwaway account if possible.")

    try:
        sid = getpass(C.GREY + "  > " + C.RESET + "Session ID: ").strip()
    except (EOFError, KeyboardInterrupt):
        return

    if not sid:
        return

    while True:
        try:
            target = input(C.GREY + "  > " + C.RESET + "Username / ID (blank exit): ").strip()
        except (EOFError, KeyboardInterrupt):
            return

        if not target:
            return

        result = lookup(target, sid)

        if "error" in result:
            err(result["error"])
            continue

        print_profile(result)
        print()
