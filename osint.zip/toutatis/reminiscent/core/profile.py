"""Async public-profile fetchers for OSINT card system (expanded edition)."""

import asyncio
import re
import httpx
from urllib.parse import quote

from ..utils.http import GENERIC_UA, IG_WEB_HEADERS
from . import discord as discord_mod


# -----------------------------
# HELPERS
# -----------------------------

def _row(label, value):
    if value is None or value in ("", [], {}):
        return None
    return [label, value]


def _compact(rows):
    return [r for r in rows if r]


async def _get(client, url, headers=None):
    try:
        return await client.get(url, headers=headers or GENERIC_UA)
    except Exception:
        return None


def _extract_links(text):
    if not text:
        return []
    return re.findall(r"https?://[^\s]+", text)


# -----------------------------
# WEBSITE METADATA (OSINT BOOST)
# -----------------------------

async def website_profile(client, url):
    try:
        r = await client.get(url, headers=GENERIC_UA, follow_redirects=True)
    except Exception:
        return None

    if not r or r.status_code != 200:
        return None

    html = r.text

    def og(tag):
        m = re.search(rf'property="{tag}" content="(.*?)"', html)
        return m.group(1) if m else None

    title = og("og:title")
    desc = og("og:description")
    image = og("og:image")

    return {
        "title": title,
        "description": desc,
        "image": image,
        "links": _extract_links(html),
    }


# -----------------------------
# GITHUB (ENHANCED)
# -----------------------------

async def github_profile(client, u):
    r = await _get(client, f"https://api.github.com/users/{u}")
    if not r or r.status_code != 200:
        return {"error": "GitHub not found"}

    d = r.json()

    fields = _compact([
        _row("Name", d.get("name")),
        _row("Bio", d.get("bio")),
        _row("Company", d.get("company")),
        _row("Location", d.get("location")),
        _row("Email", d.get("email")),
        _row("Blog", d.get("blog")),
        _row("Followers", d.get("followers")),
        _row("Following", d.get("following")),
        _row("Repos", d.get("public_repos")),
        _row("Gists", d.get("public_gists")),
        _row("Created", d.get("created_at")),
    ])

    website = await website_profile(client, d.get("blog")) if d.get("blog") else None

    return {
        "platform": "GitHub",
        "url": d.get("html_url"),
        "avatar": d.get("avatar_url"),
        "fields": fields,
        "links": website.get("links") if website else [],
    }


# -----------------------------
# REDDIT (ENHANCED)
# -----------------------------

async def reddit_profile(client, u):
    r = await _get(client, f"https://www.reddit.com/user/{u}/about.json",
                   headers={"User-Agent": "osint-tool/2.0"})
    if not r:
        return {"error": "Reddit no response"}
    if r.status_code != 200:
        return {"error": f"Reddit HTTP {r.status_code}"}

    d = r.json().get("data", {})

    fields = _compact([
        _row("Karma", d.get("total_karma")),
        _row("Link Karma", d.get("link_karma")),
        _row("Comment Karma", d.get("comment_karma")),
        _row("Created", d.get("created_utc")),
        _row("Verified Email", d.get("has_verified_email")),
    ])

    return {
        "platform": "Reddit",
        "url": f"https://reddit.com/user/{u}",
        "avatar": d.get("icon_img"),
        "fields": fields,
    }


# -----------------------------
# MASTODON (FEDERATED OSINT)
# -----------------------------

async def mastodon_profile(client, handle):
    if "@" not in handle:
        return {"error": "Use user@instance format"}

    user, instance = handle.split("@", 1)

    url = f"https://{instance}/api/v1/accounts/lookup?acct={user}"
    r = await _get(client, url)

    if not r or r.status_code != 200:
        return {"error": "Mastodon not found"}

    d = r.json()

    fields = _compact([
        _row("Display name", d.get("display_name")),
        _row("Bio", d.get("note")),
        _row("Followers", d.get("followers_count")),
        _row("Following", d.get("following_count")),
        _row("Posts", d.get("statuses_count")),
        _row("Joined", d.get("created_at")),
    ])

    return {
        "platform": "Mastodon",
        "url": d.get("url"),
        "avatar": d.get("avatar"),
        "fields": fields,
    }


# -----------------------------
# BLUESKY (AT PROTOCOL OSINT)
# -----------------------------

async def bluesky_profile(client, handle):
    url = f"https://public.api.bsky.app/xrpc/app.bsky.actor.getProfile?actor={handle}"
    r = await _get(client, url)

    if not r or r.status_code != 200:
        return {"error": "Bluesky not found"}

    d = r.json()

    fields = _compact([
        _row("Display name", d.get("displayName")),
        _row("Handle", d.get("handle")),
        _row("Description", d.get("description")),
        _row("Followers", d.get("followersCount")),
        _row("Following", d.get("followsCount")),
        _row("Posts", d.get("postsCount")),
    ])

    return {
        "platform": "Bluesky",
        "url": f"https://bsky.app/profile/{handle}",
        "avatar": d.get("avatar"),
        "fields": fields,
    }


# -----------------------------
# YOUTUBE (RSS OSINT)
# -----------------------------

async def youtube_profile(client, channel_id):
    url = f"https://www.youtube.com/feeds/videos.xml?channel_id={channel_id}"
    r = await _get(client, url)

    if not r or r.status_code != 200:
        return {"error": "YouTube channel not found"}

    xml = r.text

    title = re.search(r"<title>(.*?)</title>", xml)
    vids = len(re.findall(r"<entry>", xml))

    return {
        "platform": "YouTube",
        "url": f"https://youtube.com/channel/{channel_id}",
        "fields": _compact([
            _row("Channel", title.group(1) if title else None),
            _row("Recent videos", vids),
        ])
    }


# -----------------------------
# INSTAGRAM (ENHANCED)
# -----------------------------

async def instagram_profile(client, u):
    url = f"https://i.instagram.com/api/v1/users/web_profile_info/?username={u}"

    try:
        r = await client.get(url, headers=IG_WEB_HEADERS)
    except Exception:
        return {"error": "Instagram network error"}

    if not r or r.status_code != 200:
        return {"error": "Instagram not found"}

    try:
        user = r.json()["data"]["user"]
    except Exception:
        return {"error": "Bad Instagram payload"}

    fields = _compact([
        _row("Bio", user.get("biography")),
        _row("Followers", user.get("edge_followed_by", {}).get("count")),
        _row("Following", user.get("edge_follow", {}).get("count")),
        _row("Posts", user.get("edge_owner_to_timeline_media", {}).get("count")),
        _row("External URL", user.get("external_url")),
    ])

    return {
        "platform": "Instagram",
        "url": f"https://instagram.com/{u}",
        "avatar": user.get("profile_pic_url_hd"),
        "fields": fields,
        "links": _extract_links(user.get("biography") or ""),
    }


# -----------------------------
# DISCORD (UNCHANGED)
# -----------------------------

async def discord_profile(client, uid):
    if not uid.isdigit():
        return {"error": "Discord requires numeric ID"}

    try:
        d = await asyncio.to_thread(discord_mod.lookup, uid)
    except Exception as e:
        return {"error": str(e)}

    if "error" in d:
        return d

    return {
        "platform": "Discord",
        "url": f"https://discord.com/users/{uid}",
        "fields": [
            _row("Username", d.get("username")),
            _row("Created", d.get("created_at")),
        ]
    }


# -----------------------------
# DISPATCHER (EXPANDED)
# -----------------------------

PROFILE_FETCHERS = {
    "github": github_profile,
    "reddit": reddit_profile,
    "instagram": instagram_profile,
    "discord": discord_profile,
    "mastodon": mastodon_profile,
    "bluesky": bluesky_profile,
    "youtube": youtube_profile,
}


async def fetch_profile(platform, username):
    key = (platform or "").lower()

    fn = PROFILE_FETCHERS.get(key)
    if not fn:
        return {"error": f"No fetcher for {platform}"}

    async with httpx.AsyncClient(timeout=15, follow_redirects=True) as client:
        return await fn(client, username)
