"""Shared HTTP helpers: sync (for IG/Discord/Telegram lookups) and async (for parallel scans)."""
import asyncio
import httpx
import requests
from json import decoder


# ---------- Common headers ----------

IG_WEB_HEADERS = {
    "User-Agent": (
        "Mozilla/5.0 (iPhone; CPU iPhone OS 16_5 like Mac OS X) "
        "AppleWebKit/605.1.15 (KHTML, like Gecko) Version/16.5 "
        "Mobile/15E148 Safari/604.1"
    ),
    "x-ig-app-id": "936619743392459",
    "Accept": "*/*",
    "Accept-Language": "en-US,en;q=0.9",
}

IG_MOBILE_HEADERS = {
    "User-Agent": "Instagram 219.0.0.12.117 Android",
    "x-ig-app-id": "936619743392459",
    "Accept-Language": "en-US",
}

TG_HEADERS = {
    "User-Agent": (
        "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 "
        "(KHTML, like Gecko) Version/17.0 Safari/605.1.15"
    )
}

GENERIC_UA = {
    "User-Agent": (
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 "
        "(KHTML, like Gecko) Chrome/120.0 Safari/537.36"
    )
}


# ---------- Sync helpers ----------

def get(url, *, headers=None, cookies=None, timeout=20, allow_redirects=True):
    """requests.get wrapper that returns (response, error_str_or_None)."""
    try:
        r = requests.get(url, headers=headers, cookies=cookies,
                         timeout=timeout, allow_redirects=allow_redirects)
        return r, None
    except requests.RequestException as e:
        return None, f"Network error: {e}"


def get_json(url, *, headers=None, cookies=None, timeout=20):
    """Fetch JSON. Returns (data, error_str_or_None)."""
    r, err = get(url, headers=headers, cookies=cookies, timeout=timeout)
    if err:
        return None, err
    if r.status_code == 404:
        return None, "Not found"
    if r.status_code == 429:
        return None, "Rate limit"
    if r.status_code in (401, 403):
        return None, f"Unauthorized ({r.status_code})"
    if r.status_code != 200:
        return None, f"HTTP {r.status_code}"
    try:
        return r.json(), None
    except decoder.JSONDecodeError:
        return None, "Invalid JSON response"


def nested(d, *keys, default=None):
    """Safe nested dict access."""
    cur = d
    for k in keys:
        if not isinstance(cur, dict) or k not in cur or cur[k] is None:
            return default
        cur = cur[k]
    return cur


# ---------- Async helpers (httpx) ----------

async def fetch(url, headers=None, *, follow_redirects=True, timeout=15):
    """Async GET. Returns the httpx.Response or None on failure."""
    try:
        async with httpx.AsyncClient(timeout=timeout, follow_redirects=follow_redirects) as client:
            return await client.get(url, headers=headers)
    except Exception:
        return None


async def multi_fetch(urls, headers=None, *, follow_redirects=True, timeout=15):
    """Fetch many URLs in parallel. Returns list[httpx.Response | None]."""
    async with httpx.AsyncClient(timeout=timeout, follow_redirects=follow_redirects) as client:
        async def one(u):
            try:
                return await client.get(u, headers=headers)
            except Exception:
                return None
        return await asyncio.gather(*(one(u) for u in urls))
