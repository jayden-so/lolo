"""Shared formatting helpers: ANSI colors, banner, print primitives."""


class C:
    RESET = "\033[0m"
    BOLD = "\033[1m"
    DIM = "\033[2m"
    PURPLE = "\033[38;5;141m"
    PINK = "\033[38;5;213m"
    YELLOW = "\033[38;5;221m"
    CYAN = "\033[38;5;87m"
    GREEN = "\033[38;5;120m"
    RED = "\033[38;5;203m"
    GREY = "\033[38;5;245m"


BANNER = r"""
  ____           _      _      _                       _   
 |  _ \ ___ ___ (_)_ __(_)_   (_)___  ___ ___ _ __  __| |_ 
 | |_) / _ \ '_ \| | '_ \| \ / / / __|/ __/ _ \ '_ \/ _` __|
 |  _ <  __/ | | | | | | | V V /\__ \ (_|  __/ | | \__ \ |_ 
 |_| \_\___|_| |_|_|_| |_|\_/\_/ |___/\___\___|_| |_|___/\__|

                  R E M I N I S C E N T   O S I N T
"""


def banner():
    print(C.PURPLE + BANNER + C.RESET)
    print(C.GREY + "> " + C.RESET + "Public-data OSINT console "
          + C.DIM + "(only queries data the platform exposes publicly)" + C.RESET)
    print(C.GREY + "> " + C.RESET + "Version: " + C.PINK + "v1.1.0" + C.RESET)
    print()


def menu():
    print(C.GREY + "> " + C.RESET + C.BOLD + "Main Menu" + C.RESET)
    print(C.PINK + "1: " + C.RESET + "Instagram lookup")
    print(C.PINK + "2: " + C.RESET + "Discord lookup")
    print(C.PINK + "3: " + C.RESET + "Telegram lookup")
    print(C.PINK + "4: " + C.RESET + "Username scan (cross-platform)")
    print(C.PINK + "5: " + C.RESET + "Quit")
    print()


def info(line):
    print(C.GREY + "  " + C.RESET + line)


def ok(label, value):
    print(C.CYAN + f"  {label:<22}" + C.RESET + ": " + str(value))


def warn(msg):
    print(C.YELLOW + "  ! " + C.RESET + msg)


def err(msg):
    print(C.RED + "  x " + C.RESET + msg)


def section(title):
    print()
    print(C.PURPLE + "  --- " + title + " ---" + C.RESET)


def vstr(x):
    return "Unknown" if x is None else str(x)
