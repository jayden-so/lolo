const express = require('express');
const app = express();

// Proper CORS
const cors = require("cors");
app.use(cors());

// Routes
app.get('/api/scan/:username', (req, res) => {
  const username = req.params.username;
  res.json({
    results: {
      twitter: `https://twitter.com/${username}`,
      github: `https://github.com/${username}`
    }
  });
});

app.get('/api/ip/:ip', (req, res) => {
  const ip = req.params.ip;
  res.json({
    results: {
      ip,
      country: "Country Name",
      city: "City Name"
    }
  });
});

app.get('/api/discord/:id', (req, res) => {
  const id = req.params.id;
  res.json({
    results: {
      discord_id: id,
      username: "DiscordUser#1234",
      discriminator: "1234"
    }
  });
});

app.get('/api/email/:email', (req, res) => {
  const email = req.params.email;
  res.json({
    results: {
      email,
      verified: true,
      spam: false
    }
  });
});

// REQUIRED for Replit
const PORT = process.env.PORT || 3000;

app.listen(PORT, "0.0.0.0", () => {
  console.log(`Server running on port ${PORT}`);
});
